import greenfoot.*;
public class CardArcher extends Card
{
    public CardArcher()
    {
        super(new TroopAllyGhostArcher());
    }
    
    public void act()
    {
        super.act();
    }
}
