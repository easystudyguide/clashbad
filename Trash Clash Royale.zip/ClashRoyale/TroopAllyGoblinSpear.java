import greenfoot.*;
public class TroopAllyGoblinSpear extends TroopAllyGround
{
    public TroopAllyGoblinSpear()
    {
        super(20, 3, 75, 2, 1, 41);
        imageNumber = 14;
        troopName = "GoblinSpear";
        target = "all";
    }
    
    public void act()
    {
        super.act();
    }
}
