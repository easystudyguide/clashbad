import greenfoot.*;
public class TowerAllyTower extends TowerAlly
{
    public TowerAllyTower(int hp, int attackTime, int range)
    {
        this.hp = hp;
        this.basehp = hp;
        this.range = range;
        this.attackTime = attackTime;
        this.attackSpeed = attackTime;
    }
}
