import greenfoot.*;
public class CardNextOverlay extends Overlay
{
    
}
