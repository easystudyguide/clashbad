import greenfoot.*;
public class CardPekkaMini extends Card
{
    public CardPekkaMini()
    {
        super(new TroopAllyGhostPekkaMini());
    }
    
    public void act()
    {
        super.act();
    }
}
