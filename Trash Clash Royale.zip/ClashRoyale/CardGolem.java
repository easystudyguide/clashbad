import greenfoot.*;
public class CardGolem extends Card
{
    public CardGolem()
    {
        super(new TroopAllyGhostGolem());
    }
    
    public void act()
    {
        super.act();
    }
}
