import greenfoot.*;
public class CardDragonBaby extends Card
{
    public CardDragonBaby()
    {
        super(new TroopAllyGhostDragonBaby());
    }
    
    public void act()
    {
        super.act();
    }
}
