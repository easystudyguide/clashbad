import greenfoot.*;
public class ElixirBarOverlay extends Overlay
{
    
}
