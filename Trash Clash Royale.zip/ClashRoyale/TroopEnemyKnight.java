import greenfoot.*;
public class TroopEnemyKnight extends TroopEnemyGround
{
    public TroopEnemyKnight()
    {
        super(80, 7, 30, 1, 1, 35);
        imageNumber = 12;
        troopName = "Knight";
        target = "ground";
    }
    
    public void act()
    {
        super.act();
    }
}
