import greenfoot.*;
public class CardFireball extends Card
{
    public CardFireball()
    {
        super(new TroopAllyGhostFireball());
    }
    
    public void act()
    {
        super.act();
    }
}
