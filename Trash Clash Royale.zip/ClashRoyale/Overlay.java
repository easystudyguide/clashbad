import greenfoot.*;
public class Overlay extends Actor
{
    
}
