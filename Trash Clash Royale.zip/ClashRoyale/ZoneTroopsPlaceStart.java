import greenfoot.*;
public class ZoneTroopsPlaceStart extends ZoneTroopsPlace
{
    
}
