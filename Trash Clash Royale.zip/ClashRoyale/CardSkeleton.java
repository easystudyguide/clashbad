import greenfoot.*;
public class CardSkeleton extends Card
{
    public CardSkeleton()
    {
        super(new TroopAllyGhostSkeleton());
    }
    
    public void act()
    {
        super.act();
    }
}
