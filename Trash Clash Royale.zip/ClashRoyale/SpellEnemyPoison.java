import greenfoot.*;
public class SpellEnemyPoison extends SpellEnemyGround
{
    public SpellEnemyPoison()
    {
        super(4, 60, 152, 200, 51, "ZoneDuration");
        this.spellName = "Poison";
    }
    
    public void act()
    {
        super.act();
    }
}
