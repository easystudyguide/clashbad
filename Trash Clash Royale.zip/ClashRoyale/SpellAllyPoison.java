import greenfoot.*;
public class SpellAllyPoison extends SpellAllyGround
{
    public SpellAllyPoison()
    {
        super(4, 60, 152, 200, 51, "ZoneDuration");
        this.spellName = "Poison";
    }
    
    public void act()
    {
        super.act();
    }
}
