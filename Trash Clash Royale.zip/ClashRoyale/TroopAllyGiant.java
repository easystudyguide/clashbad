import greenfoot.*;
public class TroopAllyGiant extends TroopAllyGround
{
    public TroopAllyGiant()
    {
        super(260, 12, 30, 1, 2, 58);
        imageNumber = 19;
        troopName = "Giant";
        target = "tower";
    }
    
    public void act()
    {
        super.act();
    }
}
