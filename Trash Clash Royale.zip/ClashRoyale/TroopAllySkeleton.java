import greenfoot.*;
public class TroopAllySkeleton extends TroopAllyGround
{
    public TroopAllySkeleton()
    {
        super(5, 5, 25, 1, 1, 41);
        imageNumber = 14;
        troopName = "Skeleton";
        target = "ground";
    }
    
    public void act()
    {
        super.act();
    }
}
