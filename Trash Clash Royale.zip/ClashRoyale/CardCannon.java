import greenfoot.*;
public class CardCannon extends Card
{
    public CardCannon()
    {
        super(new TroopAllyGhostCannon());
    }
    
    public void act()
    {
        super.act();
    }
}
