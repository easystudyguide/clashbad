import greenfoot.*;
public class ZoneTroopsPlaceLeft extends ZoneTroopsPlace
{
    
}
