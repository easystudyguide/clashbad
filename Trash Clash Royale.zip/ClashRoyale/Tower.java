import greenfoot.*;
public class Tower extends Actor
{
    int hp;
    int basehp;
    int range;
    int attackTime;
    int attackSpeed;
    int distance;
    Projectile projectile;
    public void act()
    {
        
    }
}
