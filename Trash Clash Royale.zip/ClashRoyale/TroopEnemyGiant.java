import greenfoot.*;
public class TroopEnemyGiant extends TroopEnemyGround
{
    public TroopEnemyGiant()
    {
        super(260, 12, 30, 1, 2, 43);
        imageNumber = 19;
        troopName = "Giant";
        target = "tower";
    }
    
    public void act()
    {
        super.act();
    }
}
