import greenfoot.*;
public class CardGiant extends Card
{
    public CardGiant()
    {
        super(new TroopAllyGhostGiant());
    }
    
    public void act()
    {
        super.act();
    }
}
