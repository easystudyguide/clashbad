import greenfoot.*;
public class ZoneTroopsPlace extends Overlay
{
    public ZoneTroopsPlace()
    {
        getImage().setTransparency(1);
    }
}
