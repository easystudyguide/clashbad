import greenfoot.*;
public class Projectile extends Actor
{
    int damage;
    int speed;
    int time;
    String type;
}
