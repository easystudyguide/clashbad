import greenfoot.*;
public class TroopAllyPekkaMini extends TroopAllyGround
{
    public TroopAllyPekkaMini()
    {
        super(80, 30, 30, 1, 1, 58);
        imageNumber = 19;
        troopName = "PekkaMini";
        target = "ground";
    }
    
    public void act()
    {
        super.act();
    }
}
