import greenfoot.*;
public class Spell extends Actor
{
    int damage;
    int radius;
    int directionX;
    int directionY;
    int spriteTime;
    int spriteSpeed;
    int moveImageNumber;
    int attackImageNumber;
    boolean isBattling;
    boolean isUsed;
    String spellName;
    String type;
    int time;
}
