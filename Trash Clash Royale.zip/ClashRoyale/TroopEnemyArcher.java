import greenfoot.*;
public class TroopEnemyArcher extends TroopEnemyGround
{
    public TroopEnemyArcher()
    {
        super(40, 5, 85, 1, 1, 35);
        imageNumber = 12;
        troopName = "Archer";
        target = "all";
    }
    
    public void act()
    {
        super.act();
    }
}
