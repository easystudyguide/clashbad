import greenfoot.*;
public class TowerBaseCannon extends Tower
{
    public void act()
    {
        
    }
}
