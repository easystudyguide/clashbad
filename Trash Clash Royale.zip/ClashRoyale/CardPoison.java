import greenfoot.*;
public class CardPoison extends Card
{
    public CardPoison()
    {
        super(new TroopAllyGhostPoison());
    }
    
    public void act()
    {
        super.act();
    }
}
