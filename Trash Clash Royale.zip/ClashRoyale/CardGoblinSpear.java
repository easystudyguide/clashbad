import greenfoot.*;
public class CardGoblinSpear extends Card
{
    public CardGoblinSpear()
    {
        super(new TroopAllyGhostGoblinSpear());
    }
    
    public void act()
    {
        super.act();
    }
}
