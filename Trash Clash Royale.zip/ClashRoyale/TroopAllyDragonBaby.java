import greenfoot.*;
public class TroopAllyDragonBaby extends TroopAllyAir
{
    public TroopAllyDragonBaby()
    {
        super(100, 10, 60, 1, 1, 47);
        imageNumber = 16;
        troopName = "DragonBaby";
        target = "all";
    }
    
    public void act()
    {
        super.act();
    }
}
