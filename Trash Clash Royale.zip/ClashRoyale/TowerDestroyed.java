import greenfoot.*;
public class TowerDestroyed extends Tower
{
    public void act()
    {
        
    }
}
