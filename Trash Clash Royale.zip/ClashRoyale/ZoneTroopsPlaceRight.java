import greenfoot.*;
public class ZoneTroopsPlaceRight extends ZoneTroopsPlace
{
    
}
