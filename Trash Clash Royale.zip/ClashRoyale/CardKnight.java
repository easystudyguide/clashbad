import greenfoot.*;
public class CardKnight extends Card
{
    public CardKnight()
    {
        super(new TroopAllyGhostKnight());
    }
    
    public void act()
    {
        super.act();
    }
}
